# Meta Creative Studio (MVP)

Un wizard in 2 step per generare **immagini** e **video animati** (semplici) per inserzioni Meta.
- Step 1: brief + formato + durata + allegati
- Step 2: selezione template + elementi (headline, testo, bullet, CTA)
- Output: PNG (client-side) e MP4 (server-side via ffmpeg, se disponibile)

## Requisiti
- Node.js 18+ (consigliato 20)
- (Opzionale per video) **ffmpeg** installato e disponibile in PATH

## Avvio
```bash
npm install
npm run dev
```
Apri http://localhost:3000

## Note
- Le immagini vengono generate nel browser tramite Canvas e scaricate come PNG.
- I video vengono generati lato server chiamando `ffmpeg` (color background + testi con animazione leggera).
  Se ffmpeg non è installato, l'API ritorna un errore leggibile.

## Dove personalizzare
- `src/lib/templates.ts` → definizione template e regole tipografiche
- `src/lib/layout.ts` → calcolo posizioni, safe area, wrapping
- `src/app/api/render-video/route.ts` → pipeline ffmpeg (testi, durata, formato)
